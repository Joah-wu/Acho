# lvgl_dither Windows x64 Release

This archive reuses the existing C++ Windows build with renamed files.
It has not been rebuilt from the current sources; --no-preview and the
new source-level file handling improvements require a source build.

Windows 10/11 64-bit. Unzip the entire folder before running.

## Quick start

1. Run lvgl_dither.cmd once to initialize folders, then place PNG/JPG images directly in img_src (no subfolders).
2. Double-click lvgl_dither.cmd for 128x128 with dithering.
3. Results: bin_output/*.bin and img_output/dither_* previews.
4. Focus the INDEX preview window and press any key for the next image.
   Drag with the left mouse button to inspect a large image.
   After all previews, press Enter in the console to exit.

From PowerShell in this folder:

```powershell
.\lvgl_dither.exe -width 240 -height 320
.\lvgl_dither.exe -width 128 -height 64 -nodither
.\lvgl_dither.exe --help
```

Width and height each accept integers 1..2047; each defaults to 128.
Images are scaled proportionally to fit, centered and padded white.
Small images are enlarged. Output dimensions match the screen dimensions.
PNG transparency is not preserved; outputs are black and white.

Use short ASCII names, one dot, lowercase .png or .jpg extension,
and at most 19 characters INCLUDING the extension. Keep unrelated files
out of img_src. Do not give PNG and JPG inputs the same base name.
Corresponding outputs are overwritten; unrelated old outputs remain.

## Output format

Resource folders and sample images are not included in this release.
On first launch the program creates img_src, img_output and bin_output.
Place your images in img_src, then run the program again to convert.

BIN layout: 4-byte project-defined LVGL-style header, 8-byte black/white
palette, then height * ceil(width/8) pixel bytes. Verify compatibility
with your target decoder/LVGL version.

## Runtime and build

MSVC x64, C++17, /O2 /MD, OpenCV 4.6.0 Release.
OpenCV and required VC++ runtime DLLs are included beside the executable.
Keep these DLLs with the EXE when copying. No OpenCV installation required.
OpenCV license is in licenses/OpenCV-LICENSE.txt.
Original executable and build intermediates are excluded from this package.

## Changes

- Configurable -width and -height with validation and --help.
- Proportional resize and centered white padding; default 128x128.
- Corrected float pixel access in dithering.
- Preview supports the complete image, including one-pixel dimensions.

SHA256SUMS.txt lists packaged file checksums.
