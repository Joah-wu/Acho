@echo off
cd /d "%~dp0"
lvgl_dither.exe %*
